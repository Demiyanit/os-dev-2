xxd bootsect.bin
fasm bootsect.asm
fasm kernel.asm
cat bootsect.bin kernel.bin > OS.bin
qemu-system-x86_64 OS.bin